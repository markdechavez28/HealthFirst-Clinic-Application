import React, { useEffect, useMemo, useState } from "react";
import LoginPage from "./pages/LoginPage.jsx";
import RegisterPage from "./pages/RegisterPage.jsx";

import DashboardPage from "./pages/DashboardPage.jsx";
import AppointmentsWrapper from "./pages/AppointmentsWrapper.jsx";
import VideoConferenceWrapper from "./pages/VideoConferenceWrapper.jsx";
import ConsultationLogWrapper from "./pages/ConsultationLogWrapper.jsx";

function useHashRoute() {
  const getRoute = () => (window.location.hash || "#/login").replace("#", "");
  const [route, setRoute] = useState(getRoute());

  useEffect(() => {
    const onHashChange = () => setRoute(getRoute());
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  const navigate = (to) => {
    window.location.hash = to.startsWith("/") ? `#${to}` : `#/${to}`;
  };

  return { route, navigate };
}

const LS_KEYS = {
  auth: "hf_auth",
  patient: "hf_patient",
  session: "hf_session",
};

function getLS(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}

function setLS(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

export default function App() {
  const { route, navigate } = useHashRoute();
  const [session, setSession] = useState(() => getLS(LS_KEYS.session, { isAuthed: false }));

  useEffect(() => {
    if (session.isAuthed && (route === "/login" || route === "/register")) {
      navigate("/dashboard");
    }
    if (!session.isAuthed && route.startsWith("/dashboard")) {
      navigate("/login");
    }
  }, [route, session]);

  const onLogin = ({ email, password }) => {
    const auth = getLS(LS_KEYS.auth, null);
    if (!auth) return { ok: false, message: "No account found." };
    if (auth.email === email && auth.password === password) {
      const next = { isAuthed: true };
      setSession(next);
      setLS(LS_KEYS.session, next);
      navigate("/dashboard");
      return { ok: true };
    }
    return { ok: false, message: "Invalid credentials." };
  };

  const onRegister = (payload) => {
    setLS(LS_KEYS.auth, { email: payload.email, password: payload.password });
    setLS(LS_KEYS.patient, { name: payload.fullName, id: payload.patientId || "0001" });
    const next = { isAuthed: true };
    setSession(next);
    setLS(LS_KEYS.session, next);
    navigate("/dashboard");
    return { ok: true };
  };

  const onLogout = () => {
    setSession({ isAuthed: false });
    setLS(LS_KEYS.session, { isAuthed: false });
    navigate("/login");
  };

  const patient = useMemo(() => getLS(LS_KEYS.patient, {}), [session]);

  if (route === "/dashboard/appointments") {
    return <AppointmentsWrapper patient={patient} onLogout={onLogout} />;
  }
  if (route === "/dashboard/video") {
    return <VideoConferenceWrapper patient={patient} onLogout={onLogout} />;
  }
  if (route === "/dashboard/logs") {
    return <ConsultationLogWrapper patient={patient} onLogout={onLogout} />;
  }
  if (route.startsWith("/dashboard")) {
    return <DashboardPage patient={patient} onLogout={onLogout} />;
  }

  if (route === "/register") {
    return <RegisterPage onRegister={onRegister} onGoLogin={() => navigate("/login")} />;
  }

  return <LoginPage onLogin={onLogin} onGoRegister={() => navigate("/register")} />;
}
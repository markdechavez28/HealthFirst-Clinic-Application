import React from "react";

export function ConsultationLogPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-extrabold text-hf-blue">Consultation Log</h1>
      <p className="mt-2 text-slate-600">
        Placeholder page. Consultation history and records go here.
      </p>
    </div>
  );
}

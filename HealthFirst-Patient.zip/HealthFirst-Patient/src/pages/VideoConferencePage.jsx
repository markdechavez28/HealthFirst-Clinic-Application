import React from "react";

export function VideoConferencePage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-extrabold text-hf-blue">Video Conference</h1>
      <p className="mt-2 text-slate-600">
        Placeholder page. Integrate WebRTC / video SDK here.
      </p>
    </div>
  );
}
